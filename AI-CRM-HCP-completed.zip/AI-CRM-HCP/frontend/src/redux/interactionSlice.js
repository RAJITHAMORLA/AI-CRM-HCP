
import { createSlice } from "@reduxjs/toolkit";

const interactionSlice = createSlice({
  name: "interactions",

  initialState: {
    interactions: [],
  },

  reducers: {
    addInteraction: (state, action) => {
      state.interactions.unshift(action.payload);
    },
  },
});

export const { addInteraction } = interactionSlice.actions;

export default interactionSlice.reducer;