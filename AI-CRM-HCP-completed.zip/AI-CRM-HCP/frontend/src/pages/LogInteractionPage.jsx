import { useState } from "react";
import {
  Box,
  Grid,
  Paper,
  Typography,
} from "@mui/material";

import InteractionForm from "../components/InteractionForm";
import InteractionHistory from "../components/InteractionHistory";
import AIChat from "../components/AIChat";

export default function LogInteractionPage() {
  const [refreshKey, setRefreshKey] = useState(0);

  const refreshHistory = () => {
    setRefreshKey((prev) => prev + 1);
  };

  return (
    <Box
      sx={{
        p: 3,
        bgcolor: "#f5f7fb",
        minHeight: "100vh",
      }}
    >
      <Typography
        variant="h4"
        fontWeight={700}
        mb={3}
      >
        AI-First CRM HCP Module
      </Typography>

      <Grid container spacing={3}>
        {/* Left Column */}
        <Grid item xs={12} md={4}>
          <Paper
            elevation={3}
            sx={{
              p: 3,
              borderRadius: 3,
            }}
          >
            <Typography
              variant="h6"
              gutterBottom
            >
              Log Interaction
            </Typography>

            <InteractionForm
              onInteractionSaved={refreshHistory}
            />
          </Paper>
        </Grid>

        {/* Middle Column */}
        <Grid item xs={12} md={4}>
          <AIChat
            onInteractionCreated={refreshHistory}
          />
        </Grid>

        {/* Right Column */}
        <Grid item xs={12} md={4}>
          <Paper
            elevation={3}
            sx={{
              p: 3,
              borderRadius: 3,
              height: "100%",
              overflow: "auto",
            }}
          >
            <Typography
              variant="h6"
              gutterBottom
            >
              Interaction History
            </Typography>

            <InteractionHistory
              refresh={refreshKey}
            />
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}