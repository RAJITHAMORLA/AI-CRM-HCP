
import { useEffect, useState } from "react";
import {
  Paper,
  Typography,
  Box,
  Divider,
  CircularProgress,
} from "@mui/material";

import api from "../services/api";

function InteractionHistory() {
  const [interactions, setInteractions] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadInteractions = async () => {
    try {
      const response = await api.get("/interactions");
      setInteractions(response.data);
    } catch (error) {
      console.error("Error loading interactions:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInteractions();
  }, []);

  if (loading) {
    return (
      <Box sx={{ textAlign: "center", mt: 3 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (interactions.length === 0) {
    return (
      <Typography color="text.secondary">
        No interactions logged yet.
      </Typography>
    );
  }

  return (
    <Box>
      {interactions.map((item) => (
        <Paper
          key={item.id}
          sx={{
            p: 2,
            mb: 2,
            borderRadius: 2,
          }}
        >
          <Typography variant="h6">
            {item.hcp_name}
          </Typography>

          <Typography>
            <b>Interaction:</b> {item.interaction_type}
          </Typography>

          <Typography>
            <b>Date:</b> {item.interaction_date}
          </Typography>

          <Typography>
            <b>Time:</b> {item.interaction_time}
          </Typography>

          <Typography>
            <b>Topics:</b> {item.topics}
          </Typography>

          <Typography>
            <b>Sentiment:</b> {item.sentiment}
          </Typography>

          <Typography>
            <b>Follow Up:</b> {item.followup}
          </Typography>

          <Divider sx={{ mt: 2 }} />
        </Paper>
      ))}
    </Box>
  );
}

export default InteractionHistory;