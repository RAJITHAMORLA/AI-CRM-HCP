import { useState, useRef, useEffect } from "react";
import {
  Box,
  Button,
  CircularProgress,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import axios from "axios";

const API_URL = "http://localhost:8000";

export default function AIChat({ onInteractionCreated }) {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hello! Describe your HCP interaction in natural language, and I'll extract the details and log it for you.",
    },
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage = {
      role: "user",
      content: input,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const response = await axios.post(`${API_URL}/chat`, {
        message: input,
      });

      const aiResponse = response.data;

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            aiResponse.reply ||
            "Interaction processed successfully.",
        },
      ]);

      if (aiResponse.interaction_created && onInteractionCreated) {
        onInteractionCreated();
      }
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "Sorry, I couldn't process your request. Please try again.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  };

  return (
    <Paper
      elevation={3}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        p: 2,
      }}
    >
      <Typography
        variant="h6"
        fontWeight={600}
        mb={2}
      >
        AI Assistant
      </Typography>

      <Box
        sx={{
          flex: 1,
          overflowY: "auto",
          mb: 2,
        }}
      >
        <Stack spacing={2}>
          {messages.map((msg, index) => (
            <Box
              key={index}
              display="flex"
              justifyContent={
                msg.role === "user"
                  ? "flex-end"
                  : "flex-start"
              }
            >
              <Paper
                elevation={1}
                sx={{
                  p: 1.5,
                  maxWidth: "80%",
                  bgcolor:
                    msg.role === "user"
                      ? "#1976d2"
                      : "#f5f5f5",
                  color:
                    msg.role === "user"
                      ? "#fff"
                      : "#000",
                }}
              >
                <Typography
                  variant="body2"
                  sx={{ whiteSpace: "pre-wrap" }}
                >
                  {msg.content}
                </Typography>
              </Paper>
            </Box>
          ))}

          {loading && (
            <Box display="flex">
              <CircularProgress size={24} />
            </Box>
          )}

          <div ref={messagesEndRef} />
        </Stack>
      </Box>

      <TextField
        multiline
        minRows={3}
        placeholder="Describe your interaction with the HCP..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
      />

      <Button
        sx={{ mt: 2 }}
        variant="contained"
        endIcon={<SendIcon />}
        onClick={sendMessage}
        disabled={loading}
      >
        Send
      </Button>
    </Paper>
  );
}