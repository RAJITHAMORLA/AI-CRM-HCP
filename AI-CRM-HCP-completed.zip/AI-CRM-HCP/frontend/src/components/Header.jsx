
import { AppBar, Toolbar, Typography, Box } from "@mui/material";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";

function Header() {
  return (
    <AppBar position="static" sx={{ backgroundColor: "#1565C0" }}>
      <Toolbar>
        <LocalHospitalIcon sx={{ mr: 2 }} />

        <Box>
          <Typography variant="h5" fontWeight="bold">
            AI-First CRM
          </Typography>

          <Typography variant="body2">
            Healthcare Professional Interaction Module
          </Typography>
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Header;