import { useState } from "react";
import {
  Alert,
  Box,
  Button,
  MenuItem,
  Snackbar,
  TextField,
} from "@mui/material";
import api from "../services/api";

const initialState = {
  hcp_name: "",
  interaction_type: "",
  interaction_date: "",
  interaction_time: "",
  topics: "",
  sentiment: "",
  followup: "",
};

export default function InteractionForm({ onInteractionSaved }) {
  const [formData, setFormData] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [successOpen, setSuccessOpen] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    setLoading(true);
    setError("");

    try {
      await api.post("/interactions", formData);

      setFormData(initialState);
      setSuccessOpen(true);

      if (onInteractionSaved) {
        onInteractionSaved();
      }
    } catch (err) {
      console.error(err);
      setError("Failed to save interaction.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Box component="form" onSubmit={handleSubmit}>
        <TextField
          fullWidth
          margin="normal"
          label="HCP Name"
          name="hcp_name"
          value={formData.hcp_name}
          onChange={handleChange}
          required
        />

        <TextField
          select
          fullWidth
          margin="normal"
          label="Interaction Type"
          name="interaction_type"
          value={formData.interaction_type}
          onChange={handleChange}
          required
        >
          <MenuItem value="Visit">Visit</MenuItem>
          <MenuItem value="Meeting">Meeting</MenuItem>
          <MenuItem value="Call">Call</MenuItem>
          <MenuItem value="Email">Email</MenuItem>
        </TextField>

        <TextField
          fullWidth
          margin="normal"
          type="date"
          label="Interaction Date"
          name="interaction_date"
          value={formData.interaction_date}
          onChange={handleChange}
          InputLabelProps={{ shrink: true }}
          required
        />

        <TextField
          fullWidth
          margin="normal"
          type="time"
          label="Interaction Time"
          name="interaction_time"
          value={formData.interaction_time}
          onChange={handleChange}
          InputLabelProps={{ shrink: true }}
          required
        />

        <TextField
          fullWidth
          multiline
          rows={4}
          margin="normal"
          label="Topics Discussed"
          name="topics"
          value={formData.topics}
          onChange={handleChange}
          required
        />

        <TextField
          select
          fullWidth
          margin="normal"
          label="HCP Sentiment"
          name="sentiment"
          value={formData.sentiment}
          onChange={handleChange}
          required
        >
          <MenuItem value="Positive">Positive</MenuItem>
          <MenuItem value="Neutral">Neutral</MenuItem>
          <MenuItem value="Negative">Negative</MenuItem>
        </TextField>

        <TextField
          fullWidth
          multiline
          rows={3}
          margin="normal"
          label="Follow-up Actions"
          name="followup"
          value={formData.followup}
          onChange={handleChange}
          required
        />

        {error && (
          <Alert severity="error" sx={{ mt: 2 }}>
            {error}
          </Alert>
        )}

        <Button
          type="submit"
          fullWidth
          variant="contained"
          sx={{ mt: 3 }}
          disabled={loading}
        >
          {loading ? "Saving..." : "Save Interaction"}
        </Button>
      </Box>

      <Snackbar
        open={successOpen}
        autoHideDuration={3000}
        onClose={() => setSuccessOpen(false)}
      >
        <Alert
          severity="success"
          onClose={() => setSuccessOpen(false)}
          sx={{ width: "100%" }}
        >
          Interaction saved successfully!
        </Alert>
      </Snackbar>
    </>
  );
}